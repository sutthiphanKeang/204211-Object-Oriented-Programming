/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab05_2_630510647;

/**
 *
 * @author user00
 */
// นายสุทธิพันธ์ ประนันแปง 630510647

import java.util.Scanner;

class box{
    private float width;
    private float length;
    private float heigth;
    private float volume;
    private String name;
    
    public box(String name, int width, int lenght, int heigth){
        System.out.println("Hello from 1st constructor");
        volume = width * lenght * heigth;
        System.out.println("The Volume of Box: "+name+" = "+volume);
    }
    
    public box(){
        Scanner input = new Scanner(System.in);
        System.out.println("Hello from 2st constructor");
        System.out.print("Input Name of Box: ");
        name = input.nextLine();
        System.out.print("Input Width: ");
        width = input.nextFloat();
        System.out.print("Input Length: ");
        length = input.nextFloat();
        System.out.print("Input Heigth: ");
        heigth = input.nextFloat();
        
    }
    public void cal(){
        volume = width * length * heigth;
    }
    
    public void show(){
        System.out.println("The Volume of Box: "+name+" = "+volume);
    }
}
public class Lab05_2_630510647 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        box b1 = new box("SizeA",14,20,6);
        box b2 = new box();
        b2.cal();
        b2.show();
    }
    
}
