/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab05_1_630510647;

/**
 *
 * @author user00
 */
// นายสุทธิพันธ์ ประนันแปง 630510647

import java.util.Scanner;

class gpa{
    private char grade;
    private int credit;
    private int total_p;
    private int point;
    public void inputData(int i){
        Scanner input = new Scanner(System.in);
        
        System.out.println("Subject#"+i);
        System.out.print("Input Grade: ");
        grade = input.nextLine().charAt(0);
        System.out.print("Input Credit: ");
        credit = input.nextInt();
        System.out.println();
        
    }
    
    public void calGrade(){
        if (grade == 'A')
            point = 4;
        else if (grade == 'B')
            point = 3;
        else if (grade == 'C')
            point = 2;
        else if (grade == 'D')
            point = 1;
        else
            point = 0;
        
        total_p = point * credit;
        
    }
    public void setTitle(String x){
        System.out.println(x);
    }
    public int getCredit(){
        return credit;
    }
    
    public int getPoint(){
        return total_p;
    }
    
    public void printResult1(int i){
        System.out.println("Subject "+i+"       "+grade+"            "+point+"            "+credit+"          "+total_p);
    }
    
    public void setLast(String x, String y){
        System.out.println(x);
        System.out.println(y);
    }
}
public class Lab05_1_630510647 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int n;
        float t_c = 0;
        float t_p = 0;
        float t_g;
        Scanner input = new Scanner(System.in);
        System.out.print("Input N : ");
        n = input.nextInt();
        gpa [] g = new gpa[n+1];
        gpa p = new gpa();
        for(int i = 1; i < n + 1; i++){
            g[i] = new gpa();
            g[i].inputData(i);
            g[i].calGrade();
            t_c += g[i].getCredit();
            t_p += g[i].getPoint();
        }
        p.setTitle("              Grade      GradePoint    Credit     TotalPoint");
        for(int i = 1; i < n + 1; i++){
            g[i].printResult1(i);
        }
        t_g = t_p/t_c;
        p.setLast((String)("Total                                     "+(int)t_c+"         "+(int)t_p),(String)("GPA = "+t_g));

    }
    
}
