/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab06_3_630510647;

/**
 *
 * @author user00
 */
// นายสุทธิพันธ์ ประนันแปง 630510647

import java.util.Scanner;
class Voter{
    private int point_m;
    private int point_f;
    private String name;
    
    public void setData(int i){
        Scanner input = new Scanner(System.in);
        System.out.println("Input vote #"+i);
        System.out.print("Input name : ");
        name = input.nextLine();
        System.out.print("Input number of actor and number of actress : ");
        point_m = input.nextInt();
        point_f = input.nextInt();
        System.out.println();
    }
    
    public String getName(){
        return(name);
    }
    
    public int getPoint1(){
        return(point_m);
    }
    
    public int getPoint2(){
        return(point_f);
    }
    
    public void setPrintV(String g){
        System.out.print("Good luck voter -> ");
        System.out.print(g);
        System.out.println();
    }
}
class Topstar{
    private String name;

    public Topstar(String n){
        name = n;

    }
     
    public String getName(){
        return name;
    }
    
    
}
public class Lab06_3_630510647 {
    static int[] checkAndPrintVote(Voter[] t, Topstar[] m, Topstar[] f, int N){
        String sum;
        int [] item = new int[2];
        int m1 = 0;
        int m2 = 0;
        int m3 = 0;
        
        for (int i = 0; i < N; i++){
            if (t[i].getPoint1() == 1)
                m1++;
            else if (t[i].getPoint1() == 2)
                m2++;
            else if (t[i].getPoint1() == 3)
                m3++;
        }

        if (m1 > m2 && m1 > m3)
            item[0] = 1;
        else if (m2 > m1 && m2 > m3)
            item[0] = 2;
        else if (m3 > m1 && m3 > m2)
            item[0] = 3;
        

        int f1 = 0;
        int f2 = 0;
        int f3 = 0;
        for (int i = 0; i < N; i++){
            if (t[i].getPoint2() == 1)
                f1++;
            else if (t[i].getPoint2() == 2)
                f2++;
            else if (t[i].getPoint2() == 3)
                f3++;
        }

        if (f1 > f2 && f1 > f3)
            item[1] = 1;
        else if (f2 > f1 && f2 > f3)
            item[1] = 2;
        else if (f3 > f1 && f3 > f2)
            item[1] = 3;
        
        
        System.out.println("Top star award (Actor) goes to "+m[item[0] - 1].getName());
        System.out.println("Top star award (Actress) goes to "+f[item[1] - 1].getName());
        return item;
        
    }
    static String printGoodLuckPeople(Voter[] t, int n, int[] result){
        String good = "";
        for(int i = 0;i < n;i++){
            if(t[i].getPoint1() == result[0] && t[i].getPoint2() == result[1])
                good = t[i].getName() + " "; 
        }
        return good;
    }
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int n;
        System.out.print("Input N : ");
        n = input.nextInt();
        Voter [] t = new Voter[n + 1];
        
        for(int i = 0; i < n ; i++){
            t[i] = new Voter();
            t[i].setData(i+1);
            
        }
        
        Voter  v = new Voter();
        Topstar m[] = {new Topstar("Nadech"), new Topstar("Wier"), new Topstar("Mario")};
        Topstar f[] = {new Topstar("Aum"), new Topstar("Yaya"), new Topstar("Bella")};
        
        int ans[] = new int[2];
        String G;
        ans = checkAndPrintVote(t,m,f,n);
        G = printGoodLuckPeople(t, n, ans);
        v.setPrintV(G);
               
    }
    
}
