/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab06_2_630510647;

/**
 *
 * @author user00
 */

// นายสุทธิพันธ์ ประนันแปง 630510647

import java.util.Scanner;
import java.lang.Math;

class Human{
    private char sex;
    private int weight;
    private int height;
    private String name;
    
    public void setData(){
        Scanner input = new Scanner(System.in);
        
        System.out.print("Input name : ");
        name = input.nextLine();
        System.out.print("Input height : ");
        height = input.nextInt();
        System.out.print("Input weight : ");
        weight = input.nextInt();
        System.out.print("Input sex : ");
        sex = input.next().charAt(0);
        System.out.println("\n");
    }
     public String getName(){
         return(name);
     }
     
     public char getSex(){
         return(sex);
     }
     
     public int getWeight(){
         return(weight);
     }
     
     public int getHeight(){
         return(height);
     }
}
public class Lab06_2_630510647 {
    static int calAns(Human h){
        int sum;
        int wait = 0;
        if (h.getSex() == 'F')
            wait = h.getHeight() - 110;
        else if (h.getSex() == 'M')
            wait = h.getHeight() - 100;
        
        sum = h.getWeight() - wait;

        return Math.abs(sum);
    }
    
    public static void main(String[] args) {
        Human [] h = new Human[2];
        System.out.println("Input data for person #1");
        h[0] = new Human();
        h[0].setData();
        
        System.out.println("Input data for person #2");
        h[1] = new Human();
        h[1].setData();
        
        if (calAns(h[0]) - calAns(h[1]) == 0)
            System.out.println("The weight of both of them are close to the standard weight equally. ");
        else if (calAns(h[0]) - calAns(h[1]) < 0)
            System.out.println("Weight of "+h[0].getName()+" is closer to standard weight than "+h[1].getName()+".");
        else if (calAns(h[0]) - calAns(h[1]) > 0)
            System.out.println("Weight of "+h[1].getName()+" is closer to standard weight than "+h[0].getName()+".");
    }
    
}
