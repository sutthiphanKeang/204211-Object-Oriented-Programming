/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab08_1_630510647;

/**
 *
 * @author user00
 */
// นายสุทธิพันธ์ ประนันแปง 630510647

import java.util.Scanner;
class Land{
    protected int landSize ;
    public void setSize(){
        Scanner input = new Scanner(System.in);
        System.out.print("Enter land size: ");
        landSize = input.nextInt();
        
    }
    public int getLand(){
        return landSize;
    }
}

class LandForSale extends Land{
    private String titleDeed;
    private int evaluatePrice;
    private int saleStatus = 0;
    private double salePrice;
    public void setData(){
        Scanner input = new Scanner(System.in);
        System.out.print("Enter title deed: ");
        titleDeed = input.nextLine();
        System.out.print("Enter Evaluate price : ");
        evaluatePrice = input.nextInt();
    }
    public String getTitleDeed(){
        return titleDeed;
    }
    public int getEvaluatePrice(){
        return evaluatePrice;
    }
    
    public void setSaleStatus(int s){
        saleStatus = s;
    }
    public int getSaleStatus(){
        return saleStatus;
    }
    public void setSalePrice(double P){
        salePrice = P;
    }
    public double getSalePrice(){
        return salePrice;
    }
}

class LandForHouse extends Land{
    private int housePrice;
    public void setData(){
        Scanner input = new Scanner(System.in);
        System.out.print("Enter house price: ");
        housePrice = input.nextInt();
        
    }
    public int getHousePrice(){
        return housePrice;
    }
}
public class Lab08_1_630510647 {
    public static void calAns(LandForHouse [] lh, LandForSale [] ls, int h, int s){
        int home;
        double sale;
        for (int i = 0; i < h; i++){
            home = lh[i].getLand();
            for (int j = 0; j < s; j++){
                if (ls[j].getSaleStatus() == 0 && home <= ls[j].getLand()){
                    sale = ls[j].getEvaluatePrice() + (0.1 * ls[j].getEvaluatePrice()) + (0.05 * lh[i].getHousePrice());
                    ls[j].setSaleStatus(1);
                    ls[j].setSalePrice(sale);
                    break;       
                }else{
                    continue;
                }                 
            }
        }

    }
    public static void printAns(LandForSale [] ls, int s){
        double total = 0;
        for (int i = 0; i < s; i++){
            if (ls[i].getSaleStatus() == 1){
                total += ls[i].getSalePrice() - ls[i].getEvaluatePrice();
                System.out.printf(ls[i].getTitleDeed()+"\t\t\t   %.2f\n",ls[i].getSalePrice());
            }
        }
        System.out.printf("\nTotal profit = %.2f\n",total);
    }
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int NH,NL;
        System.out.print("Enter number of house: ");
        NH = input.nextInt();
        System.out.print("Enter number of lands: ");
        NL = input.nextInt();
        
        LandForHouse [] lh = new LandForHouse[NH + 1];
        LandForSale [] ls = new LandForSale[NL + 1];
        
        for(int i = 0; i < NH ; i++){
            System.out.printf("\nEnter data for house #%d\n",i+1);
            lh[i] = new LandForHouse();
            lh[i].setSize();
            lh[i].setData(); 
        }
        
        for(int i = 0; i < NL ; i++){
            System.out.printf("\nEnter data for land #%d\n",i+1);
            ls[i] = new LandForSale();
            ls[i].setSize();
            ls[i].setData();
        }
        
        calAns(lh, ls, NH, NL);
        System.out.println();
        System.out.println("Report for lands which can be sold");
        System.out.println("Title deed\t\tSale price");
        printAns(ls,NL);
    }
    
}
