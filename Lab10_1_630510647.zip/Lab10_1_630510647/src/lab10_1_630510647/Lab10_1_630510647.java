/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab10_1_630510647;

/**
 *
 * @author user00
 */
// นายสุทธิพันธ์ ประนันแปง 630510647

import java.util.Scanner;

abstract class Student{
    protected String name;
    protected int midtermScore;
    protected int finalScore;
    
    public void setInfo(){
        Scanner input = new Scanner(System.in);
        System.out.printf("Enter name: ");
        name = input.nextLine();
        System.out.printf("Enter midterm score : ");
        midtermScore = input.nextInt();
        System.out.printf("Enter final score : ");
        finalScore = input.nextInt();
    }
    
    public String getName(){ return name;}
    public int getMidtermScore(){ return midtermScore;}
    public int getFinalScore(){ return finalScore;}
    
    public abstract char calGrade(int totalScore);
}

class Undergraduate_Student extends Student{
    private int projectScore;
    
    public void setProjectScore(){
        Scanner input = new Scanner(System.in);
        System.out.printf("Enter project score : ");
        projectScore = input.nextInt();
    }
    
    public int getProjectScore(){ return projectScore;}
    
    @Override
    public char calGrade(int totalScore){
        return(totalScore >= 50 && projectScore >= 50)?'S':'U';
    }
}

class Graduate_Student extends Student{
    private int publicationNo;
    
    public void setPublicationNo(){
        Scanner input = new Scanner(System.in);
        System.out.printf("Enter number of publications : ");
        publicationNo = input.nextInt();
    }
    
    public int getPublicationNo(){ return publicationNo;}
    
    @Override
    public char calGrade(int totalScore){
        return(totalScore >= 60 && publicationNo >= 2)?'S':'U';
    }
}
public class Lab10_1_630510647 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        Student[] std = new Student[100];
        int id = 0;
        char choice;
        
        do{
            System.out.print("Enter undergraduate student or graduate student (u/g): ");
            choice = input.nextLine().charAt(0);
            if(choice == 'u'){
                std[id] = new Undergraduate_Student();
                std[id].setInfo();
                ((Undergraduate_Student)std[id]).setProjectScore();
                id++;
            }else if(choice == 'g'){
                std[id] = new Graduate_Student();
                std[id].setInfo();
                ((Graduate_Student)std[id]).setPublicationNo();
                id++;
            }else{
                System.out.println("Invalid Type of student");
            }
            System.out.print("Enter another (y/n) ? ");
            choice = input.nextLine().charAt(0);
            System.out.println();
        }while(choice == 'y');
        
        reportGrade(std, id);
    }
    
    public static void reportGrade(Student[] std, int n){
        System.out.printf("\nGrade Report\n");
        System.out.printf("= = = = = = = = =\n");
        
        int num_S = 0;
        for(int i = 0; i < n; i++){
            System.out.printf("%s",std[i].getName());
            int mid = std[i].getMidtermScore();
            int fn = std[i].getFinalScore();
            int totalScore = mid + fn;
            System.out.printf(" gets grade ");
            
            char grade;
            if(std[i] instanceof Undergraduate_Student){
                grade = std[i].calGrade(totalScore);
            }else{
                grade = std[i].calGrade(totalScore);
            }
            System.out.printf("%c.\n",grade);
            
            if(grade == 'S')
                num_S++;
        }
        
        System.out.printf("Total : Grade U = %d\tGrade S = %d\n",n - num_S,num_S);
    }
    
}
