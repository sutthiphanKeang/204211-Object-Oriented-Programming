/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab02_3_630510647;

/**
 *
 * @author user00
 */
// นายสุทธิพันธ์ ประนันแปง 630510647
import java.util.Scanner;
public class Lab02_3_630510647 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int n;
        Scanner input = new Scanner(System.in);
        System.out.print("Enter number: ");
        n = input.nextInt();
        if (checkOddEven(n) == true)
            System.out.println(n+" is even number");
        else
            System.out.println(n+" is odd number");
        if (checkPrime(n) == true)
            System.out.println(n+" is prime number");
        else
            System.out.println(n+" is not prime number");
    }
    
    public static boolean checkOddEven(int n){
        if (n % 2 == 0)
            return true;
        else
            return false;  
    }
    
    public static boolean checkPrime(int n) {  
       if (n <= 1) 
           return false;  
       for (int i = 2; i <= Math.sqrt(n); i++) {  
           if (n % i == 0) 
               return false;  
       return true;  
   }  
   
}
