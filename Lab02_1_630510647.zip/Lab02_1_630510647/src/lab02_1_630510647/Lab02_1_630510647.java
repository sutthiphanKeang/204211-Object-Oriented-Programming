/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab02_1_630510647;

/**
 *
 * @author user00
 */
// นายสุทธิพันธ์ ประนันแปง 630510647
import java.util.Scanner;
public class Lab02_1_630510647 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        char ch;
        int number;
        Scanner input = new Scanner(System.in);
        
        System.out.print("Input character: ");
        ch = input.nextLine().charAt(0);
        
        do{
            System.out.print("Input Number (between 2 and 10) : ");
            number = input.nextInt();
        }while (number < 2 || number > 10);
        
        if(Character.toLowerCase(ch) == 'a') //ใช้ if((ch == 'A') || (ch == 'a')) ก็ได้
            printStarA(number);
        else if(Character.toLowerCase(ch) == 'b')
            printStarB(number);
        else
            System.out.print("Goodbye");
    }
    
    public static void printStarA(int n){
        for(int row=1;row<=n;row++){
            for(int col=1;col<=row;col++){
                System.out.print("*");
            }
            System.out.println();
        }
    }
    
    public static void printStarB(int n){
        for(int row=0;row<n;row++){
            for(int col=(n-row)-2;col>=0;col--){
                    System.out.print(" ");
            }
            for(int col=0;col<=row;col++){
                System.out.print("*");
            }

            System.out.println();
        }
    }
    
}
