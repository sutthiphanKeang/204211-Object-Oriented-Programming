/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab07_2_630510647;

/**
 *
 * @author user00
 */
// นายสุทธิพันธ์ ประนันแปง 630510647

import java.util.Scanner;
class Employee{
    protected String id, name;
    
    public void setInfo(){
        Scanner input = new Scanner(System.in);
        System.out.print("Input id: ");
        id = input.nextLine();
        System.out.print("Input name: ");
        name = input.nextLine();
    }
    public String getId(){
        return id;
    }
    
    public String getName(){
        return name;
    }
    
}

class MonthlyEmployee extends Employee{
    private int salary;
    private int overtimePeriod;
    private int overtimeWage = 200;
    
    public void setMonthly(){
        Scanner input = new Scanner(System.in);
        System.out.print("Input salary: ");
        salary = input.nextInt();
        System.out.print("Input overtime Period: ");
        overtimePeriod = input.nextInt();
    }
    
    public void calMonthlyWage(){
        overtimePeriod = overtimePeriod * overtimeWage;
    }
    
    public int getSalary(){
        return salary;
    }
    
    public int getOvertimeWage(){
        return overtimePeriod;
    }
}

class CommissionEmployee extends Employee{
    protected int commission;
    protected int totalSale;
    protected int percentOfCommRate;
    protected int monthlyWage;
    
    public void setData(){
        Scanner input = new Scanner(System.in);
        System.out.print("Input total sale: ");
        totalSale = input.nextInt();
        System.out.print("Input percent of commission rate: ");
        percentOfCommRate = input.nextInt();      
    }
    
    public void calCommission(){
        commission = (totalSale * percentOfCommRate) / 100;
    }
    
    public int getCommission(){
        return commission;
    }
    
    
}

class WeeklyEmployee extends CommissionEmployee{
    protected int weeklyRate;
    protected int weeklyWeek;
    
    
    public void setWeekly(){
        Scanner input = new Scanner(System.in);
        System.out.print("Input weekly rate: ");
        weeklyRate = input.nextInt();
        System.out.print("Input working Week: ");
        weeklyWeek = input.nextInt();      
    }
    
    public void calMonthlyWage(){
        monthlyWage = weeklyRate * weeklyWeek;
    }
    
    public int getMonthlyWage(){
        return monthlyWage;
    }
    
}

class DailyEmployee extends CommissionEmployee{
    protected int dailyRate;
    protected int workingDay;
    
    public void setDaily(){
        Scanner input = new Scanner(System.in);
        System.out.print("Input daily rate: ");
        dailyRate = input.nextInt();
        System.out.print("Input working day: ");
        workingDay = input.nextInt();      
    }
    
    public void calMonthlyWage(){
        monthlyWage = dailyRate * workingDay;  
    }
    
    public int getMonthlyWage(){
        return monthlyWage;
    }
    
    
    
}
public class Lab07_2_630510647 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Input Number of monthly employees: ");
        int N_m = input.nextInt();
        MonthlyEmployee [] m = new MonthlyEmployee[N_m];
        int mi = 0;
        
        if(N_m != 0){
            for(int i = 0; i < N_m; i++){
                System.out.printf("\nInput person #%d\n",i+1);
                m[i] = new MonthlyEmployee();
                m[i].setInfo();
                m[i].setMonthly();
                m[i].calMonthlyWage();
                mi++;
            }
        }
        System.out.println();
        
        System.out.println("..........................................");
        System.out.print("Input Number of weekly employees: ");
        int N_w = input.nextInt();
        int wi = 0;
        
        WeeklyEmployee [] w = new WeeklyEmployee[N_w];
        if(N_w != 0){
            for(int i = 0; i < N_w; i++){
                System.out.printf("\nInput person #%d\n",i+1);
                w[i] = new WeeklyEmployee();
                w[i].setInfo();
                w[i].setData();
                w[i].calCommission();
                w[i].setWeekly();
                w[i].calMonthlyWage();
                wi++;
            }
        }
        System.out.println();
        
        System.out.println("..........................................");
        System.out.print("Input Number of daily employees: ");
        int N_d = input.nextInt();
        int di = 0;
        
        DailyEmployee [] d = new DailyEmployee[N_d];
        
        if(N_d != 0){
            for(int i = 0; i < N_d; i++){
                System.out.printf("\nInput person #%d\n",i+1);
                d[i] = new DailyEmployee();
                d[i].setInfo();
                d[i].setData();
                d[i].calCommission();
                d[i].setDaily();
                d[i].calMonthlyWage();
                di++;
            }
        }
        System.out.println();
        
        
        System.out.println("\t\t\t\tABC Company");
        if(N_m != 0)
            printAllMonthly(m, mi);
        if(N_w != 0)
            printAllWeekly(w, wi);
        if(N_d != 0)
            printAllDaily(d, di);
    }
    
    public static void printAllMonthly(MonthlyEmployee [] m, int n){
        System.out.println("Monthly Employees");
        System.out.println("ID\t\tName\t\tSalary\t\tOvertime wage\tTotal");
        String id, name;
        int salary, overtime ,total;
        int sum_s = 0, sum_o = 0, sum_t = 0;
        for(int i = 0; i < n; i++){
            id = m[i].getId();
            name = m[i].getName();
            salary = m[i].getSalary();
            sum_s += salary;
            overtime = m[i].getOvertimeWage();
            sum_o += overtime;
            total = salary + overtime;
            sum_t += total;
            System.out.printf("%s\t\t%s\t%d\t\t%d\t\t%d\n",id, name, salary, overtime, total);
        }
        System.out.printf("Total\t\t\t\t%d\t\t%d\t\t%d\n",sum_s, sum_o, sum_t);
        System.out.println();
    }
    
    public static void printAllWeekly(WeeklyEmployee [] w, int n){
        System.out.println("Weekly Employees");
        System.out.println("ID\t\tName\t\tCommission\tMonthly wage\tTotal");
        String id, name;
        int commission, Monthly ,total;
        int sum_c = 0, sum_m = 0, sum_t = 0;
        for(int i = 0; i < n; i++){
            id = w[i].getId();
            name = w[i].getName();
            commission = w[i].getCommission();
            sum_c += commission;
            Monthly = w[i].getMonthlyWage();
            sum_m += Monthly;
            total = commission + Monthly;
            sum_t += total;
            System.out.printf("%s\t\t%s\t%d\t\t%d\t\t%d\n",id, name, commission, Monthly, total);
        }
        System.out.printf("Total\t\t\t\t%d\t\t%d\t\t%d\n",sum_c, sum_m, sum_t);
        System.out.println();
    }
    
    public static void printAllDaily(DailyEmployee [] d, int n){
        System.out.println("Daily Employees");
        System.out.println("ID\t\tName\t\tCommission\tMonthly wage\tTotal");
        String id, name;
        int commission, Monthly ,total;
        int sum_c = 0, sum_m = 0, sum_t = 0;
        for(int i = 0; i < n; i++){
            id = d[i].getId();
            name = d[i].getName();
            commission = d[i].getCommission();
            sum_c += commission;
            Monthly = d[i].getMonthlyWage();
            sum_m += Monthly;
            total = commission + Monthly;
            sum_t += total;
            System.out.printf("%s\t\t%s\t%d\t\t%d\t\t%d\n",id, name, commission, Monthly, total);
        }
        System.out.printf("Total\t\t\t\t%d\t\t%d\t\t%d\n",sum_c, sum_m, sum_t);
        System.out.println();
    }
    
}
