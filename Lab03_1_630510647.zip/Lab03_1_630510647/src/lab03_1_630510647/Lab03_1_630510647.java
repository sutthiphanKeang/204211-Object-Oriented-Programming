/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab03_1_630510647;

/**
 *
 * @author user00
 */
// นายสุทธิพันธ์ ประนันแปง 630510647
import java.util.Scanner;

class Human{
    private char gender;
    private float weight;
    private float height;
    private String shape;
    
    public void setData(){
        Scanner input = new Scanner(System.in);
        do{
            System.out.print("Enter gender: ");
            gender = input.nextLine().charAt(0);
            gender = Character.toUpperCase(gender);
            
        }while((gender != 'F') && (gender != 'M'));
        System.out.print("Enter weight: ");
        weight = input.nextFloat();
        System.out.print("Enter height: ");
        height = input.nextFloat();

    }
    
    public void calShape(){
        if (gender == 'F'){
            if (weight <= height - 110)
                shape = "Your shape is OK";
            else
                shape = "Your shape is not OK";
        }else {
            if (weight <= height - 100)
                shape = "Your shape is OK";
            else
                shape = "Your shape is not OK";
        }
            
    }
    
    public void printResult(){
        System.out.print(shape);
    }
}

public class Lab03_1_630510647 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Human h = new Human();
        h.setData();
        h.calShape();
        h.printResult();
    }
    
}
