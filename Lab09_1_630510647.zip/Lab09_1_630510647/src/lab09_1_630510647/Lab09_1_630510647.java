/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab09_1_630510647;

/**
 *
 * @author user00
 */
// นายสุทธิพันธ์ ประนันแปง 630510647

import java.util.Scanner;
class OrderItem{
    private String foodName;
    private int price;
    private int numDish;
    
    public void setData(){
        Scanner input = new Scanner(System.in);
        System.out.print("Enter food name: ");
        foodName = input.nextLine();
        System.out.print("Enter price : ");
        price = input.nextInt();
        System.out.print("Enter number of dishes : ");
        numDish = input.nextInt();
    }
    
    public void showData(){
        if (foodName.length() >= 8)
            System.out.printf("%s\t%d\t\t\t%d\n",foodName, price, numDish);
        else
            System.out.printf("%s\t\t%d\t\t\t%d\n",foodName, price, numDish);
    }
    
    public int getPrice(){
        return price;
    }
    
    public int getDish(){
        return numDish;
    }
}

class Order{
    private String orderId;
    private String tableNo;
    private int numberOfItem;
    private int N = 10;
    private OrderItem [] item = new OrderItem[N];
    private double totalPrice;
    
    public void setData(){
        Scanner input = new Scanner(System.in);
        System.out.print("Enter order ID : ");
        orderId = input.nextLine();
        System.out.print("Enter Table No.: ");
        tableNo = input.nextLine();
        System.out.print("Enter number of food items : ");
        numberOfItem = input.nextInt();
        System.out.println("*************************************************************");
        if (numberOfItem > 10)
            N = numberOfItem;
    }
    
    public void calData(){
        for(int i = 0; i < numberOfItem; i++){
            item[i] = new OrderItem();
            item[i].setData();
            totalPrice += item[i].getPrice() * item[i].getDish();
            System.out.println("*************************************************************");
        }
    }
    
    public void showData(){
        
        System.out.println("Order ID - "+orderId+"\tTable No. - "+tableNo);
        System.out.println("Food Name\tPrice/Dish(Baht)\tQTY");
        for(int i = 0; i < numberOfItem; i++){
            item[i].showData();
        }
        System.out.println("Tatal Price = "+totalPrice+" Bath");
    }  

    
}
public class Lab09_1_630510647 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Order order = new Order();
        order.setData();
        order.calData();
        order.showData();
    }
    
}
