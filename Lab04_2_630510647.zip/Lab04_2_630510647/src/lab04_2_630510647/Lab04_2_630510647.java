/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab04_2_630510647;

/**
 *
 * @author user00
 */
// นายสุทธิพันธ์ ประนันแปง 630510647
import java.util.*;

class Massage{
    private String word;
    private String newword = "";
    private ArrayList n_text;
    
    public void inputText(){
        Scanner input = new Scanner(System.in);
        System.out.print("Input text : ");
        word = input.nextLine();
    }
    
    public void convertTexttoASCII(){
        int point = 0;
        ArrayList<Character> n_text = new ArrayList<Character>();
     
        for (int i = 0; i < word.length(); i++){
            char a = 'a';
            n_text.add(word.charAt(i));
            point = ((int)n_text.get(i) - (int)a  + 3)%26 + (int)a;
            newword += (char)point;
        }
     
    }
    
    public void printResult(){
        int j = 0;
        for (int i = 0; i < word.length(); i++){
            if (j != 3){
                System.out.print(Character.toUpperCase(newword.charAt(i)));
                j++;
            }
            else{
                System.out.print(" ");
                i--;
                j = 0;
            }
        }
        if (word.length() % 3 == 2)
            System.out.print("#");
        if (word.length() % 3 == 1)
            System.out.print("##");
        
        System.out.println();
    }
}
public class Lab04_2_630510647 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Massage m = new Massage();
        m.inputText();
        m.convertTexttoASCII();
        m.printResult();
    }
    
}
