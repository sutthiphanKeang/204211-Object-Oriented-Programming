/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab04_1_630510647;

/**
 *
 * @author user00
 */
// นายสุทธิพันธ์ ประนันแปง 630510647
import java.util.Scanner;
class Matrix{
    private int size;
    private int [][] data = new int[50][50];
    boolean identityStatus;
    
    public void setSize(){
        Scanner input = new Scanner(System.in);
        System.out.print("Input size : ");
        size = input.nextInt();
    }
    
    public void setData(){
        int i,j;
        Scanner input = new Scanner(System.in);
        
        for(i=0;i<size;i++){
            for(j=0;j<size;j++){
                System.out.printf("Input number [%d][%d] : ",i,j);
                data[i][j] = input.nextInt();
            }
            System.out.println();
        }
    }
    
    public void checkIdentity(){
        int i,j;
        identityStatus = true;
        for(i = 0;i < size && identityStatus;i++){
                for(j = 0;j < size && identityStatus;j++){
                    if((i == j) && (data[i][j] != 1))
                        identityStatus = false;
                    else if ((i != j) && (data[i][j] != 0))
                        identityStatus = false;
                }
        }
    }
    
    public void showIdentity(){
        if(identityStatus)
            System.out.print("This matrix is identity matrix.");
        else
            System.out.print("This matrix is not identity matrix.");
    }
}
public class Lab04_1_630510647 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Matrix m = new Matrix();
        m.setSize();
        m.setData();
        m.checkIdentity();
        m.showIdentity();
    }
    
}
