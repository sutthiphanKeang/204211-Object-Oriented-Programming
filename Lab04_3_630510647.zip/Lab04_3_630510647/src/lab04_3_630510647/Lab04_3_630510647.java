/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab04_3_630510647;

/**
 *
 * @author user00
 */
// นายสุทธิพันธ์ ประนันแปง 630510647

import java.util.Scanner;

class Student{
    private int num;
    private int num_s;
    private String co_list;
    private String [] num_c;
    private int i_snum;
    private String name = "";
    
    public void inputData(){
        Scanner input = new Scanner(System.in);

        System.out.print("Student name: ");
        name = input.nextLine();
        System.out.print("Number of subjects: ");
        num_s = input.nextInt();
        input.nextLine();
        System.out.print("Course list: ");
        co_list = input.nextLine();
        num_c  = co_list.split(" ");
        System.out.println();
        
    }
    public void printResult(String x){
        for (int i = 0; i < num_c.length;i++){
            if(num_c[i].equals(x))
                System.out.println(name);
        }
    }

}
public class Lab04_3_630510647 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int num;
        String name;
        Scanner input = new Scanner(System.in);
        System.out.print("Input number of students : ");
        num = input.nextInt();
        input.nextLine();
        System.out.println();
        Student [] s = new Student[num+1];
        
        for(int i = 0; i < num ; i++){
            s[i] = new Student();
            s[i].inputData();

            
        }
        System.out.print("Input subject for searching : ");
        name = input.nextLine();
        for(int j = 0; j < num; j++){
            s[j].printResult(name);
        }
    }
    
}
