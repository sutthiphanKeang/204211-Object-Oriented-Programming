package lab10_2_630510647;
// นายสุทธิพันธ์ ประนันแปง 630510647

import java.util.Scanner;
abstract class Shape2Dim{
    protected int N;
    public void setN(int n){ N = n;}
    abstract void draw();
}

class Rhombus extends Shape2Dim{ 
    Rhombus(){N = 0;}
    void draw(){ //วาดรูปสี่เหลี่ยมขนมเปียกปูน
        if (N > 0) {
            int j,i;
            String fsq = "%" + N+"c\n";
            String fsq2;System.out.printf(fsq,'*');
            for (i=1; i<N;i++ ){   
                fsq2 = "%" + (N-i)+"c%"+(2*i)+"c\n";
                    System.out.printf(fsq2,'*','*');
            }
            
            for (i=N-2; i>=1;i--){
                fsq2 = "%" + (N-i)+"c%"+(2*i)+"c\n";
                System.out.printf(fsq2,'*','*');
            }
            System.out.printf(fsq,'*');
        }
        
    }
}
class Square extends Shape2Dim{  
    Square(){ N=0;}
    void draw(){//วาดรูปสี่เหลี่ยม
        if (N > 0){//จงเติมCode//วาดรูปสี่เหลี่ยม
            String flo = "*";
            String em = " ";
            System.out.println(flo.repeat(N));
            int i;
            for (i=1; i<N;i++ ){   
                System.out.println("*"+em.repeat(N - 2)+"*");
            }
            System.out.println(flo.repeat(N));
        }
    }
}

class Triangle extends Shape2Dim{
    Triangle(){ N=0;}
    void draw(){
        if (N > 0){
            String flo = "* ";
            int j,i;
            String fsq = "%" + N+"c\n";
            String fsq2;System.out.printf(fsq,'*');
            for (i=1; i<(N - 1);i++ ){   
                fsq2 = "%" + (N-i)+"c%"+(2*i)+"c\n";
                    System.out.printf(fsq2,'*','*');
        }
        System.out.println(flo.repeat(N));
    }
}

public static class Lab10_2_630510647 {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        int N;
        char t;
        int n;
        System.out.print("Input M : ");
        N = input.nextInt();

        Shape2Dim s[] = new Shape2Dim[N+1];
        for(int i = 0; i < N ; i++){
            System.out.print("Input Type (R S or T) and Size : ");
            t = input.next().charAt(0);
            n = input.nextInt();
            input.nextLine();
            if (t == 'R'){
                s[i] = new Rhombus();
                s[i].setN(n);
            }
            if (t == 'S'){
                s[i] = new Square();
                s[i].setN(n);
            }
            if (t == 'T'){
                s[i] = new Triangle();
                s[i].setN(n);
            }
        }
        System.out.println();
        
        System.out.println("Rhombus");
        for(int j = 0; j < N; j++){
            if (s[j] instanceof Rhombus){
                ((Rhombus)s[j]).draw();
            }
            System.out.println();
        }
        System.out.println();

        System.out.println("Square\n");
        for(int j = 0; j < N; j++){
            if (s[j] instanceof Square){
                ((Square)s[j]).draw();
            }
            System.out.println();
        }
        System.out.println();

        System.out.println("Triangle");
        for(int j = 0; j < N; j++){
            if (s[j] instanceof Triangle){
                ((Triangle)s[j]).draw();
            }
            System.out.println();
        }
        System.out.println();

        }
    }
}


    

