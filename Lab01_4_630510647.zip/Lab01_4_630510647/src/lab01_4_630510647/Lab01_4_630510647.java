/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab01_4_630510647;

/**
 *
 * @author user00
 */
// นายสุทธิพันธ์ ประนันแปง 630510647
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Collections;
public class Lab01_4_630510647 {
    public static void main(String[] args) {
        ArrayList<Integer> ans1 = new ArrayList<Integer>();
        ArrayList<Integer> ans2 = new ArrayList<Integer>();
        ArrayList<Integer> sum = new ArrayList<Integer>();
        int a1 = 0, a2 = 0,;
        int r = 0;
        Scanner sn = new Scanner(System.in);
        System.out.println("Enter Array A ");
        
        for(int j=0;j<5;j++){
            a1 = sn.nextInt();
            ans1.add(a1);
        }
        
        System.out.println("Enter Array B ");
        for(int j=0;j<5;j++){
            a2 = sn.nextInt();
            ans2.add(a2);
        }
        
        for(int j=0;j<5;j++){
            int mo1 = 0, mo2 = 0;
            mo1 = ans1.get(j);
            mo2 = ans2.get(j);
            sum.add(mo1);
            sum.add(mo2);
        }
        Collections.sort(sum);
        
        System.out.print(sum.get(0));
        for(int j=1;j<10;j++){
            int Final = 0;
            Final = sum.get(j);
            System.out.print(" " +Final);
        }
    }
    
}
