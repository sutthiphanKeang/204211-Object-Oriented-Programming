/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab03_3_630510647;

/**
 *
 * @author user00
 */
// นายสุทธิพันธ์ ประนันแปง 630510647

import java.util.Scanner;

class Student{
    private int num;
    private String s_pass;
    private int m_score;
    private int f_score;
    private String grade;
    int sum;
    
    public void setData(int i){
        Scanner input = new Scanner(System.in);
        System.out.println("Enter data for student #"+i);
        
        System.out.print("Enter student ID: ");
        s_pass = input.nextLine();
        System.out.print("Enter midterm and final scores: ");
        m_score = input.nextInt();
        f_score = input.nextInt();
            

    }
    
    public void calScore(){
        sum = m_score + f_score;
        if (sum >= 85)
            grade = "A";
        else if (sum >= 80 && sum <= 84)
            grade = "B+";
        else if (sum >= 75 && sum <= 79)
            grade = "B";
        else if (sum >= 60 && sum <= 74)
            grade = "C+";
        else if (sum >= 55 && sum <= 59)
            grade = "C";
        else if (sum >= 50 && sum <= 54)
            grade = "D+";
        else if (sum >= 45 && sum <= 49)
            grade = "D";
        else
            grade = "F";
    }
    
    public void printResult(int i){
        System.out.println(i+"    "+s_pass+"    "+sum+"       "+grade);
    }
}

public class Lab03_3_630510647 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int n;
        Scanner input = new Scanner(System.in);
        System.out.print("Enter N: ");
        n = input.nextInt();
        Student [] s = new Student[n+1];
        
        for(int i = 1; i < n + 1; i++){
            s[i] = new Student();
            s[i].setData(i);
            s[i].calScore();
            
        }
        
        for(int i = 1; i < n + 1; i++){
            s[i].printResult(i);
        }
       
    }
    
}
