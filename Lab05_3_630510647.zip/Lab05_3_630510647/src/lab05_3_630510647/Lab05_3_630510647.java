/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab05_3_630510647;

/**
 *
 * @author user00
 */
// นายสุทธิพันธ์ ประนันแปง 630510647

import java.util.Scanner;

class Menu{
    private int choice;
    public void setChoice(){
        Scanner input = new Scanner(System.in);
        System.out.println("**********");
        System.out.println("1.push");
        System.out.println("2.pop");
        System.out.println("3.show");
        System.out.println("4.exit");
        System.out.println("**********");
        System.out.print("Please select choice : ");
        choice = input.nextInt();
        
        
    }
    public int getChoice(){
        return choice;
    }
    
}

class Stack{
    Scanner input = new Scanner(System.in);
    private int [] item = new int[5];
    private int top;
    
    public Stack(){
        top = -1;
    }
    public void push(int x){  
        if (isFull()){
            System.out.println("stack is full");
            System.out.println();
     
        }
        else
            item[top + 1] = x;
            top += 1;
            System.out.println();
        
    }
    public void pop(){ 
        if (isEmpty()){
            System.out.println("stack is empty");
            
        }
        else{
            System.out.println("pop "+item[top]);
            top -= 1;   
        }
        System.out.println();
    }
    public void show(){
        if (isEmpty()){
            System.out.println("stack is empty");
    
        }
        else{
            for(int i = 0; i <= top; i++){
                System.out.print(item[i]+" ");
                //System.out.println();
            }System.out.println();
        }
        System.out.println();
    }
    public boolean isEmpty(){
        if (top == -1)
            return true;
        else
            return false;
    }
    public boolean isFull(){
        if (top == 4)
            return true;
        else
            return false;
    }
}
public class Lab05_3_630510647 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Menu m = new Menu();
        Stack s = new Stack();
        int choice;
        do{
            m.setChoice();
            choice = m.getChoice();
            if (choice == 1){
                int x;
                System.out.print("Enter data : ");
                x = input.nextInt();
                s.push(x);
            }
            else if (choice == 2)
                s.pop();
            else if (choice == 3)
                s.show();
            else if (choice == 4)
                break;
        }while(true);
        System.out.println("Bye bye");
    }
    
}
