/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab01_2_630510647;
/**
 *
 * @author user00
 */
// นายสุทธิพันธ์ ประนันแปง 630510647
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Collections;
public class Lab01_2_630510647 {
    public static void main(String[] args) {
        ArrayList<Integer> ans = new ArrayList<Integer>();
        int score = 0, ave = 0, sum = 0;
        int i = 0, j = 0, k = 0;
        Scanner sn = new Scanner(System.in);
        System.out.println("Enter score between 1-100 or press 0 for stop ");
        
        do {
            score = sn.nextInt();
            if(score != 0 && score <= 100)
            {
                ans.add(score);
                sum += score;
                i++;
            }
            if(score == 0)
            {
                break;
            }
            if(score > 100)
            {
                System.out.println("Enter score again(between 1-100 or press 0 for stop) ");
                continue;
            }
 
        }while (true);
        
        ave = sum / i;
        Integer max = Collections.max(ans);
        Integer min = Collections.min(ans);
        System.out.println("Maximum Score = " + max);
        System.out.println("Minimum Score = " + min);
        System.out.println("Average Score = " + ave);
        
        for(j=0;j<i;j++) {
            if(ans.get(j) < ave)
            {
                k++;
            }
        }
        System.out.println("The number of students whoscoredbelowaverage score = " + k);
        }
        
    }  

