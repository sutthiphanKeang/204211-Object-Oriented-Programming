/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab02_2_630510647;

/**
 *
 * @author user00
 */
// นายสุทธิพันธ์ ประนันแปง 630510647
import java.util.Scanner;
public class Lab02_2_630510647 {
    

    /**
     * @param args the command line arguments
     */

    public static void main(String[] args) {
        int q1 = 0,q2 = 0,q3 = 0,q4 = 0,xa = 0,ya = 0,op = 0;
        int n;
        int x = 0, y = 0;
        Scanner input = new Scanner(System.in);
        System.out.print("Enter N: ");
        n = input.nextInt();
        
        for(int i = 0;i < n;i++){
            System.out.print("Enter point: ");
            x = input.nextInt();
            y = input.nextInt();
            if (checkQuadrant(x, y) == 1)
                q1++;
            else if (checkQuadrant(x, y) == 2)
                q2++;
            else if (checkQuadrant(x, y) == 3)
                q3++;
            else if (checkQuadrant(x, y) == 4)
                q4++;
            else if (checkQuadrant(x, y) == 5)
                xa++;
            else if (checkQuadrant(x, y) == 6)
                ya++;
            else if (checkQuadrant(x, y) == 7)
                op++;
        }
        
        System.out.println("Number of points in Qaudrant 1 = " + q1);
        System.out.println("Number of points in Qaudrant 2 = " + q2);
        System.out.println("Number of points in Qaudrant 3 = " + q3);
        System.out.println("Number of points in Qaudrant 4 = " + q4);
        System.out.println("Number of points on X axis = " + xa);
        System.out.println("Number of points on Y axis = " + ya);
        System.out.println("Number of points on origin point = " + op);
    }
    
    public static int checkQuadrant(int x, int y){
        if (x > 0 & y > 0)
            return 1;
        else if (x < 0 & y >0)
            return 2;
        else if (x < 0 & y < 0)
            return 3;
        else if (x > 0 & y < 0)
            return 4;
        else if (x == 0 & y != 0)
            return 5;
        else if (y == 0 & x != 0)
            return 6;
        else if ( x == 0 & y == 0)
            return 7;

        
    }
    
}
