/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab11_1_630510647;

/**
 *
 * @author user00
 */
// นายสุทธิพันธ์ ประนันแปง 630510647

import java.util.Scanner;
import java.util.Arrays;
public class Lab11_1_630510647 {
    public static <TYPE extends Comparable> TYPE getCenter(TYPE x, TYPE y, TYPE z){
        Object [] num = {x, y, z};
        Arrays.sort(num);
        TYPE ans = (TYPE)num[1];
        return ans;
    }
    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter 3 integer numbers");
        int a = input.nextInt();
        int b = input.nextInt();
        int d = input.nextInt();
        System.out.println();
        
        
        System.out.println("Enter 3 characters");
        char e = input.next().charAt(0);
        char f = input.next().charAt(0);
        char g = input.next().charAt(0);
        System.out.println();
        
        System.out.println("Enter 3 float numbers");
        float h = input.nextFloat();
        float i = input.nextFloat();
        float j = input.nextFloat();
        System.out.println();
        
        System.out.println(getCenter(a,b,d));
        System.out.println(getCenter(e,f,g));
        System.out.println(getCenter(h,i,j));
    }
    
}
