/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab11_2_630510647;

/**
 *
 * @author user00
 */
// นายสุทธิพันธ์ ประนันแปง 630510647

import java.util.Scanner;
class Queue <TYPE>{
    private int front;
    private int rear;
    private int count;
    private int N;
    private Object [] item;
    Queue(int x) { //สร้างคิว
        N = x;
        item = new Object[N];
        front = 0;
        rear = -1;
        count = 0;
    }
    public void enqueue( TYPE  v) { //เพิ่มข้อมูลเข้าสู่คิว
        if (rear < N - 1){
            rear++;
            item[rear] = v;
            count++;
        }else
            System.out.println("Queue is full");
    }

    TYPE dequeue(){//นำข้อมูลออกจากคิวแล้วส่งค่ากลับเป็นค่านั้น
        TYPE queueFront;
        if (!isEmpty()){
            queueFront = (TYPE)item[front];
            front++;
            count--;
            return queueFront;  
        }else 
            return (TYPE)"Queue is empty.";
    }
    
    public void show(){
        if (isEmpty()){
            System.out.println("Nothing to show."); 
        }
        else{
            for(int i = front; i <= rear; i++){
                System.out.print(item[i]+" ");
            }System.out.println();
        }
        System.out.print("*******************************************************\n");

    }
    public boolean isEmpty(){
        if (count == 0)
            return true;
        else
            return false;
    }
    public boolean isFull(){
        if (rear >= N - 1)
            return true;
        else
            return false;
    }
}
public class Lab11_2_630510647 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int N;
        System.out.print("Input N : ");
        N = input.nextInt();
        Queue <Integer> C_i = new Queue(N);
        Queue <Character> C_c = new Queue(N);
        char se;
        int choice;
        int i = 0;
        System.out.print("Select int or char(i or c): ");
        se = input.next().charAt(0);
        System.out.println();
        if(se == 'i'){
            do{
                System.out.println("\t1) enqueue");
                System.out.println("\t2) dequeue");
                System.out.println("\t3) show");
                System.out.println("\t4) exit");
                System.out.print("Select choice : ");
                choice = input.nextInt();
                if (choice == 1){
                    int x;
                    if (i < N){
                        System.out.print("Input data for enqueue : ");
                        x = input.nextInt();
                        C_i.enqueue(x);
                        System.out.println("OK\n*******************************************************");
                    }else{
                        C_i.enqueue(0);
                        System.out.println("*******************************************************");
                    }
                    i++;
                }
                else if (choice == 2){
                    System.out.print(C_i.dequeue());
                    System.out.print("\n*******************************************************\n");
                }
                else if (choice == 3)
                    C_i.show();
                else if (choice == 4){
                    System.out.print("Bye.\n*******************************************************\n");
                    break;
                }
                System.out.println();
            }while(true);
        }else if(se == 'c'){
            do{
                System.out.println("\t1) enqueue");
                System.out.println("\t2) dequeue");
                System.out.println("\t3) show");
                System.out.println("\t4) exit");
                System.out.print("Select choice : ");
                choice = input.nextInt();
                if (choice == 1){
                    char x;
                    if (i < N){
                        System.out.print("Input data for enqueue : ");
                        x = input.next().charAt(0);
                        C_c.enqueue(x);
                        System.out.println("OK\n*******************************************************");
                    }else{
                        C_c.enqueue('z');
                        System.out.println("*******************************************************");
                    }
                    i++;
                }
                else if (choice == 2){
                    System.out.print(C_c.dequeue());
                    System.out.print("\n*******************************************************\n");
                }
                else if (choice == 3)
                    C_c.show();
                else if (choice == 4){
                    System.out.print("Bye.\n*******************************************************\n");
                    break;  
                }
                System.out.println();
            }while(true);
        }    
    }
    
}
