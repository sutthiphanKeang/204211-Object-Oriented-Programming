/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab01_1_630510647;
// นาย สุทธิพันธ์ ประนันแปง 630510647
/**
 *
 * @author user00
 */
import java.util.Scanner;
public class Lab01_1_630510647 {
    public static void main(String[] args) {
        int A, B, C, num = 0; //รับค่าจำนวนเต็ม A, B, C และให้ num เท่ากับ 0
        Scanner sn = new Scanner(System.in); //input
        System.out.print("Input A: "); //แสดงผล
        A = sn.nextInt(); //รับค่า A
        System.out.print("Input B: "); //แสดงผล
        B = sn.nextInt(); //รับค่า B
        System.out.print("Input C: "); //แสดงผล
        C = sn.nextInt(); //รับค่า C
        System.out.printf("%d %d", A, B); //แสดงผล A, B
        
        num = (A * A) + (B * B); //ยกกำลังสอง A บวก ยกกำลังสอง B
        while (num <= C) { //loop เมื่อ num น้อยกว่าเท่า C
            System.out.print(" " + num); //เพิ่มคำตอบไป
            A = B; //เปลี่ยนค่า A
            B = num; //เปลี่ยนค่า B
            num = (A * A) + (B * B); //ยกกำลังสอง A บวก ยกกำลังสอง B ตัวใหม่
        }
        
    }
    
}
