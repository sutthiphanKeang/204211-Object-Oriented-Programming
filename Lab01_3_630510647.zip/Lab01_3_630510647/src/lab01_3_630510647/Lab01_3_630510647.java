/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab01_3_630510647;

/**
 *
 * @author user00
 */
// นายสุทธิพันธ์ ประนันแปง 630510647
import java.util.Scanner;
public class Lab01_3_630510647 {
    public static void main(String[] args) {
        int N = 0, sum = 0;
        int n1 = 0, n2, n_f = 0;
        Scanner sn = new Scanner(System.in);
        System.out.println("Enter N ");
        N = sn.nextInt();
        
        sum = N;
        
        do{
            n1 = N % 5;
            n2 = ((int)(N/5)) * 2;
            sum += n2;
            N = n2 + n1;
            if (N < 5)
            {
                break;
            }
        }while (true);
        
        
        System.out.print("Total number of drinking bottles = "+sum+" The remaining empty bottles = "+N);
    }
    
}
