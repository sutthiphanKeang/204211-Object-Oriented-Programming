/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab06_1_630510647;

/**
 *
 * @author user00
 */
// นายสุทธิพันธ์ ประนันแปง 630510647

import java.util.Scanner;

class Drawing{
    public void drawTriangle(int N){
        for(int row=1;row<=N;row++){
            for(int col=1;col<=row;col++){
                System.out.print("*");
            }
            System.out.println();
        }
    }
    
    public void drawTriangle(int N, char X){
        for(int row=0;row<N;row++){
            for(int col=(N-row)-1;col>=0;col--){
                    System.out.print(X);
            }
            for(int col=0;col<=row;col++){
                System.out.print(" ");
            }

            System.out.println();
        }
    }
}
public class Lab06_1_630510647 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Drawing myDrawing = new Drawing();
        int n;
        char x;
        System.out.print("Input N: ");
        n = input.nextInt();
        System.out.print("Input X: ");
        x = input.next().charAt(0);
        
        myDrawing.drawTriangle(n);
        myDrawing.drawTriangle(n, x);
    }
    
}
