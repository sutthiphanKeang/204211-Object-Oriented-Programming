/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab03_2_630510647;
/**
 *
 * @author user00
 */
// นายสุทธิพันธ์ ประนันแปง 630510647

import java.util.Scanner;

class Parking{
    private char type;
    private int time;
    private double cost;
    
    
    public void setData(int i){
        Scanner input = new Scanner(System.in);
        System.out.println("Enter data for vehicle parking #"+i);
        do{
            System.out.print("Enter vehicle type: ");
            type = input.nextLine().charAt(0);
            type = Character.toUpperCase(type);
            
        }while((type != 'C') && (type != 'M'));
        System.out.print("Enter minute: ");
        time = input.nextInt();
    }
    
    public void calCost(){
        if (type == 'C'){
            if (time <= 60)
                cost = (time * 1);
            else if (time > 60 && time <= 120)
                cost = (60 + ((time - 60) * 0.75));
  
            else if (time > 120 && time <= 240)
                cost = (60 + (120 * 0.75) + ((time - 120) * 0.5));
            else
                cost = (60 + (120 * 0.75) + (240 * 0.5) + ((time - 240) * 0.25));
        }else {
            
            if (time > 10)
                if (time % 10 == 0){
                    int h_time;
                    h_time = (time / 60);
                    cost = (h_time * 5);
                }else{
                    float h_time;
                    h_time = ( time / 60 ) + 1;
                    cost = ((int)(h_time) * 5);
                    
                }   
            else
                cost = 1;
           
        }
            
    }
    
    public void printResult(){
        System.out.println("cost = "+cost+" baht(s)");
    }
}

public class Lab03_2_630510647 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Parking p1,p2;
        
        p1 = new Parking();
        p1.setData(1);
        p1.calCost();
        p1.printResult();
        
        p2 = new Parking();
        p2.setData(2);
        p2.calCost();
        p2.printResult();
    }
    
}
